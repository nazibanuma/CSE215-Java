package zoomanagementsystem;

public interface Feedable {

    public String getFoodType();
}
